//
//  GiftModel.m
//  presentAnimation
//
//  Created by 许博 on 16/7/15.
//  Copyright © 2016年 许博. All rights reserved.
//

#import "GiftModel.h"

@implementation GiftModel

@end
