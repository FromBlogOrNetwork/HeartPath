//
//  JQBounceSpot1Animation.h
//  JQIndicatorViewDemo
//
//  Created by James on 15/7/21.
//  Copyright (c) 2015年 JQ. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#import "JQIndicatorAnimationProtocol.h"

@interface JQBounceSpot1Animation : NSObject <JQIndicatorAnimationProtocol>



@end
