//
//  JQBounceSpot2Animation.h
//  JQIndicatorViewDemo
//
//  Created by 家琪 on 15/7/27.
//  Copyright (c) 2015年 JQ. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#import "JQIndicatorAnimationProtocol.h"

@interface JQBounceSpot2Animation : NSObject <JQIndicatorAnimationProtocol>

@end
