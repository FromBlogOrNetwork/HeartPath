//
//  JQMusic2Animation.h
//  JQIndicatorViewDemo
//
//  Created by James on 15/7/22.
//  Copyright (c) 2015年 JQ. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#import "JQIndicatorAnimationProtocol.h"

@interface JQMusic2Animation : NSObject<JQIndicatorAnimationProtocol>

@end
