//
//  JQCollectionView.h
//  
//
//  Created by James on 15/7/18.
//
//

#import <UIKit/UIKit.h>

@interface JQCollectionView : UICollectionViewController

- (IBAction)changeColor:(UIBarButtonItem *)sender;

@end
